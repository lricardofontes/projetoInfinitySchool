create view hora_mensal_servidor_view
            (servidor_id, ano, mes, hora_ordinaria, hora_vd, hora_extraordinaria, adicional_hora_ordinaria,
             hora_vd_noturno, adicional_hora_extraordinaria, hora_vd_diurno)
as
SELECT servidor_id,
       ano,
       mes,
       hora_ordinaria,
       hora_vd,
       hora_extraordinaria,
       adicional_hora_ordinaria,
       adicional_hora_vd           AS hora_vd_noturno,
       adicional_hora_extraordinaria,
       hora_vd - adicional_hora_vd AS hora_vd_diurno
FROM (SELECT hora_mensal_servidor.servidor_id,
             hora_mensal_servidor.ano,
             hora_mensal_servidor.mes,
             sum(hora_mensal_servidor.hora_ordinaria)                   AS hora_ordinaria,
             sum(hora_mensal_servidor.hora_vd)                          AS hora_vd,
             sum(hora_mensal_servidor.hora_extraordinaria)              AS hora_extraordinaria,
             sum(hora_mensal_servidor.adicional_noturno_ordinaria)      AS adicional_hora_ordinaria,
             sum(hora_mensal_servidor.adicional_noturno_vd)             AS adicional_hora_vd,
             sum(hora_mensal_servidor.adicional_noturno_extraordinaria) AS adicional_hora_extraordinaria
      FROM (SELECT servidor.id                                         AS servidor_id,
                   EXTRACT(year FROM horario.inicio)                   AS ano,
                   EXTRACT(month FROM horario.inicio)                  AS mes,
                   0                                                   AS hora_ordinaria,
                   sum(
                           CASE
                               WHEN afastamento.id IS NULL AND escala.pagamento_vd IS TRUE
                                   THEN EXTRACT(epoch FROM horario.fim) - EXTRACT(epoch FROM horario.inicio)
                               ELSE 0::numeric
                               END * 1000::numeric) / 3600000::numeric AS hora_vd,
                   sum(
                           CASE
                               WHEN afastamento.id IS NULL AND escala.pagamento_vd IS FALSE
                                   THEN EXTRACT(epoch FROM horario.fim) - EXTRACT(epoch FROM horario.inicio)
                               ELSE 0::numeric
                               END * 1000::numeric) / 3600000::numeric AS hora_extraordinaria,
                   0                                                   AS adicional_noturno_ordinaria,
                   sum(
                           CASE
                               WHEN afastamento.id IS NOT NULL OR escala.pagamento_vd IS FALSE OR (EXTRACT(epoch FROM
                                                                                                           CASE
                                                                                                               WHEN
                                                                                                                   horario.fim::date =
                                                                                                                   horario.inicio::date AND
                                                                                                                   horario.fim::time without time zone >
                                                                                                                   adicional_noturno.hora_inicial::time without time zone AND
                                                                                                                   horario.inicio::time without time zone <
                                                                                                                   adicional_noturno.hora_final::time without time zone
                                                                                                                   THEN
                                                                                                                   horario.fim::date +
                                                                                                                   adicional_noturno.hora_final +
                                                                                                                   (horario.fim::time without time zone -
                                                                                                                    adicional_noturno.hora_inicial::time without time zone)
                                                                                                               WHEN
                                                                                                                   horario.fim::time without time zone <
                                                                                                                   adicional_noturno.hora_final::time without time zone OR
                                                                                                                   horario.fim::time without time zone >
                                                                                                                   adicional_noturno.hora_inicial::time without time zone
                                                                                                                   THEN horario.fim
                                                                                                               ELSE horario.fim::date + adicional_noturno.hora_final::interval
                                                                                                               END) -
                                                                                                   EXTRACT(epoch FROM
                                                                                                           CASE
                                                                                                               WHEN
                                                                                                                   horario.inicio::time without time zone >
                                                                                                                   adicional_noturno.hora_inicial::time without time zone OR
                                                                                                                   horario.inicio::time without time zone <
                                                                                                                   adicional_noturno.hora_final::time without time zone
                                                                                                                   THEN horario.inicio
                                                                                                               ELSE horario.inicio::date + adicional_noturno.hora_inicial::interval
                                                                                                               END)) < 0::numeric
                                   THEN 0::numeric
                               ELSE EXTRACT(epoch FROM
                                            CASE
                                                WHEN horario.fim::date = horario.inicio::date AND
                                                     horario.fim::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone AND
                                                     horario.inicio::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone THEN
                                                    horario.fim::date + adicional_noturno.hora_final +
                                                    (horario.fim::time without time zone -
                                                     adicional_noturno.hora_inicial::time without time zone)
                                                WHEN horario.fim::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone OR
                                                     horario.fim::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone
                                                    THEN horario.fim
                                                ELSE horario.fim::date + adicional_noturno.hora_final::interval
                                                END) - EXTRACT(epoch FROM
                                                               CASE
                                                                   WHEN horario.inicio::time without time zone >
                                                                        adicional_noturno.hora_inicial::time without time zone OR
                                                                        horario.inicio::time without time zone <
                                                                        adicional_noturno.hora_final::time without time zone
                                                                       THEN horario.inicio
                                                                   ELSE horario.inicio::date + adicional_noturno.hora_inicial::interval
                                                                   END)
                               END * 1000::numeric) / 3600000::numeric AS adicional_noturno_vd,
                   sum(
                           CASE
                               WHEN afastamento.id IS NOT NULL OR escala.pagamento_vd IS TRUE OR (EXTRACT(epoch FROM
                                                                                                          CASE
                                                                                                              WHEN
                                                                                                                  horario.fim::date =
                                                                                                                  horario.inicio::date AND
                                                                                                                  horario.fim::time without time zone >
                                                                                                                  adicional_noturno.hora_inicial::time without time zone AND
                                                                                                                  horario.inicio::time without time zone <
                                                                                                                  adicional_noturno.hora_final::time without time zone
                                                                                                                  THEN
                                                                                                                  horario.fim::date +
                                                                                                                  adicional_noturno.hora_final +
                                                                                                                  (horario.fim::time without time zone -
                                                                                                                   adicional_noturno.hora_inicial::time without time zone)
                                                                                                              WHEN
                                                                                                                  horario.fim::time without time zone <
                                                                                                                  adicional_noturno.hora_final::time without time zone OR
                                                                                                                  horario.fim::time without time zone >
                                                                                                                  adicional_noturno.hora_inicial::time without time zone
                                                                                                                  THEN horario.fim
                                                                                                              ELSE horario.fim::date + adicional_noturno.hora_final::interval
                                                                                                              END) -
                                                                                                  EXTRACT(epoch FROM
                                                                                                          CASE
                                                                                                              WHEN
                                                                                                                  horario.inicio::time without time zone >
                                                                                                                  adicional_noturno.hora_inicial::time without time zone OR
                                                                                                                  horario.inicio::time without time zone <
                                                                                                                  adicional_noturno.hora_final::time without time zone
                                                                                                                  THEN horario.inicio
                                                                                                              ELSE horario.inicio::date + adicional_noturno.hora_inicial::interval
                                                                                                              END)) < 0::numeric
                                   THEN 0::numeric
                               ELSE EXTRACT(epoch FROM
                                            CASE
                                                WHEN horario.fim::date = horario.inicio::date AND
                                                     horario.fim::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone AND
                                                     horario.inicio::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone THEN
                                                    horario.fim::date + adicional_noturno.hora_final +
                                                    (horario.fim::time without time zone -
                                                     adicional_noturno.hora_inicial::time without time zone)
                                                WHEN horario.fim::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone OR
                                                     horario.fim::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone
                                                    THEN horario.fim
                                                ELSE horario.fim::date + adicional_noturno.hora_final::interval
                                                END) - EXTRACT(epoch FROM
                                                               CASE
                                                                   WHEN horario.inicio::time without time zone >
                                                                        adicional_noturno.hora_inicial::time without time zone OR
                                                                        horario.inicio::time without time zone <
                                                                        adicional_noturno.hora_final::time without time zone
                                                                       THEN horario.inicio
                                                                   ELSE horario.inicio::date + adicional_noturno.hora_inicial::interval
                                                                   END)
                               END * 1000::numeric) / 3600000::numeric AS adicional_noturno_extraordinaria
            FROM hub_bombeiro.grupamento_horario horario
                     JOIN hub_bombeiro.grupamento grupamento
                          ON grupamento.id = horario.grupamento_id AND grupamento.deleted_at IS NULL
                     JOIN hub_bombeiro.posto posto ON posto.id = grupamento.posto_id AND posto.deleted_at IS NULL
                     JOIN hub_bombeiro.escala_evento escala ON escala.id = posto.escala_id AND escala.deleted_at IS NULL
                     JOIN hub_bombeiro.vaga vaga ON vaga.grupamento_horario_id = horario.id AND vaga.deleted_at IS NULL
                     JOIN hub_bombeiro.servidor_escala_evento servidor_escala
                          ON servidor_escala.vaga_id = vaga.id AND servidor_escala.deleted_at IS NULL
                     JOIN hub_bombeiro.servidor servidor
                          ON servidor.id = servidor_escala.servidor_id AND servidor.deleted_at IS NULL
                     JOIN hub_bombeiro.adicional_noturno adicional_noturno ON adicional_noturno.deleted_at IS NULL AND
                                                                              horario.inicio::date >=
                                                                              adicional_noturno.vigencia_inicio AND
                                                                              horario.inicio::date <= COALESCE(
                                                                                      adicional_noturno.vigencia_final::timestamp without time zone,
                                                                                      horario.inicio) AND
                                                                              (escala.pagamento_vd IS FALSE AND
                                                                               adicional_noturno.categoria::text =
                                                                               'EXTRA_ORD'::text OR
                                                                               escala.pagamento_vd IS TRUE AND
                                                                               adicional_noturno.categoria::text =
                                                                               'VD'::text)
                     LEFT JOIN hub_bombeiro.afastamento afastamento
                               ON afastamento.deleted_at IS NULL AND afastamento.militar_id = servidor.id AND
                                  (horario.inicio::date >= afastamento.data_inicial AND
                                   horario.inicio::date <= afastamento.data_final OR
                                   horario.fim::date >= afastamento.data_inicial AND
                                   horario.fim::date <= afastamento.data_final)
            WHERE horario.deleted_at IS NULL
              AND escala.status::text <> 'RASCUNHO'::text
            GROUP BY servidor.id, (EXTRACT(year FROM horario.inicio)), (EXTRACT(month FROM horario.inicio))
            UNION ALL
            SELECT servidor.id                                         AS servidor_id,
                   EXTRACT(year FROM horario.data_hora_inicio)         AS ano,
                   EXTRACT(month FROM horario.data_hora_inicio)        AS mes,
                   sum(
                           CASE
                               WHEN folga.id IS NULL AND afastamento.id IS NULL AND escala.extraordinaria IS FALSE THEN
                                   EXTRACT(epoch FROM horario.data_hora_final) -
                                   EXTRACT(epoch FROM horario.data_hora_inicio)
                               ELSE 0::numeric
                               END * 1000::numeric -
                           CASE
                               WHEN folga.id IS NULL AND afastamento.id IS NULL AND escala.extraordinaria IS FALSE AND
                                    horario.intervalo_inicio IS NOT NULL AND horario.intervalo_final IS NOT NULL THEN
                                   EXTRACT(epoch FROM horario.intervalo_final) -
                                   EXTRACT(epoch FROM horario.intervalo_inicio)
                               ELSE 0::numeric
                               END * 1000::numeric) / 3600000::numeric AS hora_ordinaria,
                   0                                                   AS hora_vd,
                   sum(
                           CASE
                               WHEN folga.id IS NULL AND afastamento.id IS NULL AND escala.extraordinaria IS TRUE THEN
                                   EXTRACT(epoch FROM horario.data_hora_final) -
                                   EXTRACT(epoch FROM horario.data_hora_inicio)
                               ELSE 0::numeric
                               END * 1000::numeric) / 3600000::numeric AS hora_extraordinaria,
                   sum(
                           CASE
                               WHEN folga.id IS NOT NULL OR afastamento.id IS NOT NULL OR
                                    escala.extraordinaria IS TRUE OR (EXTRACT(epoch FROM
                                                                              CASE
                                                                                  WHEN horario.data_hora_final::date =
                                                                                       horario.data_hora_inicio::date AND
                                                                                       horario.data_hora_final::time without time zone >
                                                                                       adicional_noturno.hora_inicial::time without time zone AND
                                                                                       horario.data_hora_inicio::time without time zone <
                                                                                       adicional_noturno.hora_final::time without time zone
                                                                                      THEN
                                                                                      horario.data_hora_final::date +
                                                                                      adicional_noturno.hora_final +
                                                                                      (horario.data_hora_final::time without time zone -
                                                                                       adicional_noturno.hora_inicial::time without time zone)
                                                                                  WHEN
                                                                                      horario.data_hora_final::time without time zone <
                                                                                      adicional_noturno.hora_final::time without time zone OR
                                                                                      horario.data_hora_final::time without time zone >
                                                                                      adicional_noturno.hora_inicial::time without time zone
                                                                                      THEN horario.data_hora_final
                                                                                  ELSE horario.data_hora_final::date +
                                                                                       adicional_noturno.hora_final::interval
                                                                                  END) - EXTRACT(epoch FROM
                                                                                                 CASE
                                                                                                     WHEN
                                                                                                         horario.data_hora_inicio::time without time zone >
                                                                                                         adicional_noturno.hora_inicial::time without time zone OR
                                                                                                         horario.data_hora_inicio::time without time zone <
                                                                                                         adicional_noturno.hora_final::time without time zone
                                                                                                         THEN horario.data_hora_inicio
                                                                                                     ELSE
                                                                                                         horario.data_hora_inicio::date +
                                                                                                         adicional_noturno.hora_inicial::interval
                                                                                                     END)) < 0::numeric
                                   THEN 0::numeric
                               ELSE EXTRACT(epoch FROM
                                            CASE
                                                WHEN horario.data_hora_final::date = horario.data_hora_inicio::date AND
                                                     horario.data_hora_final::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone AND
                                                     horario.data_hora_inicio::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone THEN
                                                    horario.data_hora_final::date + adicional_noturno.hora_final +
                                                    (horario.data_hora_final::time without time zone -
                                                     adicional_noturno.hora_inicial::time without time zone)
                                                WHEN horario.data_hora_final::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone OR
                                                     horario.data_hora_final::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone
                                                    THEN horario.data_hora_final
                                                ELSE horario.data_hora_final::date + adicional_noturno.hora_final::interval
                                                END) - EXTRACT(epoch FROM
                                                               CASE
                                                                   WHEN
                                                                       horario.data_hora_inicio::time without time zone >
                                                                       adicional_noturno.hora_inicial::time without time zone OR
                                                                       horario.data_hora_inicio::time without time zone <
                                                                       adicional_noturno.hora_final::time without time zone
                                                                       THEN horario.data_hora_inicio
                                                                   ELSE horario.data_hora_inicio::date +
                                                                        adicional_noturno.hora_inicial::interval
                                                                   END)
                               END * 1000::numeric) / 3600000::numeric AS adicional_noturno_ordinaria,
                   0                                                   AS adicional_noturno_vd,
                   sum(
                           CASE
                               WHEN folga.id IS NOT NULL OR afastamento.id IS NOT NULL OR
                                    escala.extraordinaria IS FALSE OR (EXTRACT(epoch FROM
                                                                               CASE
                                                                                   WHEN horario.data_hora_final::date =
                                                                                        horario.data_hora_inicio::date AND
                                                                                        horario.data_hora_final::time without time zone >
                                                                                        adicional_noturno.hora_inicial::time without time zone AND
                                                                                        horario.data_hora_inicio::time without time zone <
                                                                                        adicional_noturno.hora_final::time without time zone
                                                                                       THEN
                                                                                       horario.data_hora_final::date +
                                                                                       adicional_noturno.hora_final +
                                                                                       (horario.data_hora_final::time without time zone -
                                                                                        adicional_noturno.hora_inicial::time without time zone)
                                                                                   WHEN
                                                                                       horario.data_hora_final::time without time zone <
                                                                                       adicional_noturno.hora_final::time without time zone OR
                                                                                       horario.data_hora_final::time without time zone >
                                                                                       adicional_noturno.hora_inicial::time without time zone
                                                                                       THEN horario.data_hora_final
                                                                                   ELSE horario.data_hora_final::date +
                                                                                        adicional_noturno.hora_final::interval
                                                                                   END) - EXTRACT(epoch FROM
                                                                                                  CASE
                                                                                                      WHEN
                                                                                                          horario.data_hora_inicio::time without time zone >
                                                                                                          adicional_noturno.hora_inicial::time without time zone OR
                                                                                                          horario.data_hora_inicio::time without time zone <
                                                                                                          adicional_noturno.hora_final::time without time zone
                                                                                                          THEN horario.data_hora_inicio
                                                                                                      ELSE
                                                                                                          horario.data_hora_inicio::date +
                                                                                                          adicional_noturno.hora_inicial::interval
                                                                                                      END)) < 0::numeric
                                   THEN 0::numeric
                               ELSE EXTRACT(epoch FROM
                                            CASE
                                                WHEN horario.data_hora_final::date = horario.data_hora_inicio::date AND
                                                     horario.data_hora_final::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone AND
                                                     horario.data_hora_inicio::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone THEN
                                                    horario.data_hora_final::date + adicional_noturno.hora_final +
                                                    (horario.data_hora_final::time without time zone -
                                                     adicional_noturno.hora_inicial::time without time zone)
                                                WHEN horario.data_hora_final::time without time zone <
                                                     adicional_noturno.hora_final::time without time zone OR
                                                     horario.data_hora_final::time without time zone >
                                                     adicional_noturno.hora_inicial::time without time zone
                                                    THEN horario.data_hora_final
                                                ELSE horario.data_hora_final::date + adicional_noturno.hora_final::interval
                                                END) - EXTRACT(epoch FROM
                                                               CASE
                                                                   WHEN
                                                                       horario.data_hora_inicio::time without time zone >
                                                                       adicional_noturno.hora_inicial::time without time zone OR
                                                                       horario.data_hora_inicio::time without time zone <
                                                                       adicional_noturno.hora_final::time without time zone
                                                                       THEN horario.data_hora_inicio
                                                                   ELSE horario.data_hora_inicio::date +
                                                                        adicional_noturno.hora_inicial::interval
                                                                   END)
                               END * 1000::numeric) / 3600000::numeric AS adicional_noturno_extraordinaria
            FROM hub_bombeiro.grupo_data_horario horario
                     JOIN hub_bombeiro.grupo_escala grupo
                          ON grupo.id = horario.grupo_escala_id AND grupo.deleted_at IS NULL
                     JOIN hub_bombeiro.escala_unidade escala
                          ON escala.id = grupo.escala_id AND escala.deleted_at IS NULL
                     JOIN hub_bombeiro.servidor_escala servidor_escala
                          ON servidor_escala.grupo_escala_id = grupo.id AND servidor_escala.deleted_at IS NULL
                     JOIN hub_bombeiro.servidor servidor
                          ON servidor.id = servidor_escala.servidor_id AND servidor.deleted_at IS NULL
                     JOIN hub_bombeiro.adicional_noturno adicional_noturno ON adicional_noturno.deleted_at IS NULL AND
                                                                              horario.data_hora_inicio::date >=
                                                                              adicional_noturno.vigencia_inicio AND
                                                                              horario.data_hora_inicio::date <=
                                                                              COALESCE(
                                                                                      adicional_noturno.vigencia_final::timestamp without time zone,
                                                                                      horario.data_hora_inicio) AND
                                                                              (escala.extraordinaria IS TRUE AND
                                                                               adicional_noturno.categoria::text =
                                                                               'EXTRA_ORD'::text OR
                                                                               escala.extraordinaria IS FALSE AND
                                                                               adicional_noturno.categoria::text =
                                                                               'ORDINARIA'::text)
                     LEFT JOIN hub_bombeiro.afastamento afastamento
                               ON afastamento.deleted_at IS NULL AND afastamento.militar_id = servidor.id AND
                                  (horario.data_hora_inicio::date >= afastamento.data_inicial AND
                                   horario.data_hora_inicio::date <= afastamento.data_final OR
                                   horario.data_hora_final::date >= afastamento.data_inicial AND
                                   horario.data_hora_final::date <= afastamento.data_final)
                     LEFT JOIN hub_bombeiro.folga_escala_unidade folga
                               ON folga.deleted_at IS NULL AND folga.servidor_escala_id = servidor_escala.id AND
                                  folga.grupo_data_horario_id = horario.id
            WHERE horario.deleted_at IS NULL
              AND escala.status::text <> 'RASCUNHO'::text
            GROUP BY servidor.id, (EXTRACT(year FROM horario.data_hora_inicio)),
                     (EXTRACT(month FROM horario.data_hora_inicio))) hora_mensal_servidor
      GROUP BY hora_mensal_servidor.servidor_id, hora_mensal_servidor.ano, hora_mensal_servidor.mes) unnamed_subquery
ORDER BY ano DESC, mes DESC;

alter table hora_mensal_servidor_view
    owner to usr_bd_cbm_hub;

