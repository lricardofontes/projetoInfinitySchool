create view servidor_view
            (id, nome, matricula, posto_graduacao, quadro, setor, unidade, cidade_lotacao, idade, sexo, raca, religiao,
             natureza_funcional, data_admissao, tempo_servico_ano, tempo_servico_mes, tempo_servico_dia,
             situacao_funcional, cargo, simbolo, cnh, condutor_aeronave, cedido, em_atividade, pis_pasep, email_pessoal,
             email_institucional, titulo_eleitor, telefone_celular, tipo_sanguineo, unidade_id, setor_id, desenvolvedor,
             updated_at, fiplan, cpf, data_obito, regiao)
as
SELECT servidor.id,
       servidor.nome,
       servidor.matricula,
       servidor.posto_graduacao,
       quadro.sigla                                                                                                   AS quadro,
       setor.sigla                                                                                                    AS setor,
       unidade.sigla                                                                                                  AS unidade,
       municipio.nome                                                                                                 AS cidade_lotacao,
       EXTRACT(year FROM age(CURRENT_DATE::timestamp with time zone,
                             servidor.data_nascimento::timestamp with time zone))::integer                            AS idade,
       servidor.sexo,
       servidor.raca,
       religiao.nome                                                                                                  AS religiao,
       servidor.tipo_posto_graduacao                                                                                  AS natureza_funcional,
       servidor.data_admissao::date                                                                                   AS data_admissao,
       COALESCE(EXTRACT(year FROM age(CURRENT_DATE::timestamp without time zone, servidor.data_admissao))::integer,
                0)                                                                                                    AS tempo_servico_ano,
       COALESCE(EXTRACT(month FROM age(CURRENT_DATE::timestamp without time zone, servidor.data_admissao))::integer,
                0)                                                                                                    AS tempo_servico_mes,
       COALESCE(EXTRACT(day FROM age(CURRENT_DATE::timestamp without time zone, servidor.data_admissao))::integer,
                0)                                                                                                    AS tempo_servico_dia,
       situacao_funcional.nome                                                                                        AS situacao_funcional,
       cargo.cargo,
       simbolo.nome                                                                                                   AS simbolo,
       servidor.cnh,
       servidor.condutor_aeronave,
       servidor.cedido,
       servidor.em_atividade,
       servidor.pis_pasep_nit                                                                                         AS pis_pasep,
       servidor.email_pessoal,
       servidor.email_institucional,
       servidor.titulo_eleitor,
       servidor.telefone_celular,
       servidor.tipo_sanguineo,
       unidade.id                                                                                                     AS unidade_id,
       setor.id                                                                                                       AS setor_id,
       servidor.desenvolvedor,
       servidor.updated_at,
       servidor.fiplan,
       servidor.cpf,
       servidor.data_obito,
       regiao.nome                                                                                                    AS regiao
FROM hub_bombeiro.servidor servidor
         LEFT JOIN hub_bombeiro.quadro quadro ON servidor.quadro_id = quadro.id
         JOIN hub_bombeiro.setor setor ON servidor.setor_id = setor.id
         JOIN hub_bombeiro.unidade unidade ON setor.unidade_id = unidade.id
         JOIN hub_bombeiro.regiao regiao ON unidade.regiao_id = regiao.id
         LEFT JOIN hub_bombeiro.religiao religiao ON servidor.religiao_id = religiao.id
         JOIN hub_bombeiro.situacao_funcional situacao_funcional
              ON servidor.situacao_funcional_id = situacao_funcional.id
         LEFT JOIN hub_bombeiro.cargo cargo ON servidor.cargo_id = cargo.id
         LEFT JOIN hub_bombeiro.simbolo simbolo ON cargo.simbolo_id = simbolo.id
         LEFT JOIN hub_bombeiro.municipio municipio ON setor.municipio_id = municipio.id
WHERE servidor.deleted_at IS NULL;

alter table servidor_view
    owner to usr_bd_cbm_hub;

