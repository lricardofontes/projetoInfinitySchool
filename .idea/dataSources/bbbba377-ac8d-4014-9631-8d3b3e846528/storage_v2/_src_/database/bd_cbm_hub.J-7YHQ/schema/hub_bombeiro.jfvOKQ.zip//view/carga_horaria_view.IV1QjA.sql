create view carga_horaria_view(id, grupo, carga_horaria, adicional_noturno, escala_id) as
SELECT grupo_escala.id,
       grupo_escala.grupo,
       round(sum((EXTRACT(epoch FROM horario.data_hora_final - horario.data_hora_inicio) -
                  CASE
                      WHEN horario.intervalo_inicio IS NOT NULL AND horario.intervalo_final IS NOT NULL THEN
                          EXTRACT(epoch FROM horario.intervalo_final) - EXTRACT(epoch FROM horario.intervalo_inicio)
                      ELSE 0::numeric
                      END) / 3600::numeric), 1)                      AS carga_horaria,
       round(sum(
                     CASE
                         WHEN (EXTRACT(epoch FROM
                                       CASE
                                           WHEN horario.data_hora_final::date = horario.data_hora_inicio::date AND
                                                horario.data_hora_final::time without time zone >
                                                adicional_noturno.hora_inicial::time without time zone AND
                                                horario.data_hora_inicio::time without time zone <
                                                adicional_noturno.hora_final::time without time zone THEN
                                               horario.data_hora_final::date + adicional_noturno.hora_final +
                                               (horario.data_hora_final::time without time zone -
                                                adicional_noturno.hora_inicial::time without time zone)
                                           WHEN horario.data_hora_final::time without time zone <
                                                adicional_noturno.hora_final::time without time zone OR
                                                horario.data_hora_final::time without time zone >
                                                adicional_noturno.hora_inicial::time without time zone
                                               THEN horario.data_hora_final
                                           ELSE horario.data_hora_final::date + adicional_noturno.hora_final::interval
                                           END) - EXTRACT(epoch FROM
                                                          CASE
                                                              WHEN horario.data_hora_inicio::time without time zone >
                                                                   adicional_noturno.hora_inicial::time without time zone OR
                                                                   horario.data_hora_inicio::time without time zone <
                                                                   adicional_noturno.hora_final::time without time zone
                                                                  THEN horario.data_hora_inicio
                                                              ELSE horario.data_hora_inicio::date +
                                                                   adicional_noturno.hora_inicial::interval
                                                              END)) < 0::numeric THEN 0::numeric
                         ELSE EXTRACT(epoch FROM
                                      CASE
                                          WHEN horario.data_hora_final::date = horario.data_hora_inicio::date AND
                                               horario.data_hora_final::time without time zone >
                                               adicional_noturno.hora_inicial::time without time zone AND
                                               horario.data_hora_inicio::time without time zone <
                                               adicional_noturno.hora_final::time without time zone THEN
                                              horario.data_hora_final::date + adicional_noturno.hora_final +
                                              (horario.data_hora_final::time without time zone -
                                               adicional_noturno.hora_inicial::time without time zone)
                                          WHEN horario.data_hora_final::time without time zone <
                                               adicional_noturno.hora_final::time without time zone OR
                                               horario.data_hora_final::time without time zone >
                                               adicional_noturno.hora_inicial::time without time zone
                                              THEN horario.data_hora_final
                                          ELSE horario.data_hora_final::date + adicional_noturno.hora_final::interval
                                          END) - EXTRACT(epoch FROM
                                                         CASE
                                                             WHEN horario.data_hora_inicio::time without time zone >
                                                                  adicional_noturno.hora_inicial::time without time zone OR
                                                                  horario.data_hora_inicio::time without time zone <
                                                                  adicional_noturno.hora_final::time without time zone
                                                                 THEN horario.data_hora_inicio
                                                             ELSE horario.data_hora_inicio::date +
                                                                  adicional_noturno.hora_inicial::interval
                                                             END)
                         END * 1000::numeric) / 3600000::numeric, 1) AS adicional_noturno,
       escala.id                                                     AS escala_id
FROM hub_bombeiro.grupo_escala grupo_escala
         JOIN hub_bombeiro.grupo_data_horario horario ON grupo_escala.id = horario.grupo_escala_id
         JOIN hub_bombeiro.escala_unidade escala ON escala.id = grupo_escala.escala_id AND escala.deleted_at IS NULL
         JOIN hub_bombeiro.adicional_noturno adicional_noturno ON adicional_noturno.deleted_at IS NULL AND
                                                                  horario.data_hora_inicio::date >=
                                                                  adicional_noturno.vigencia_inicio AND
                                                                  horario.data_hora_inicio::date <= COALESCE(
                                                                          adicional_noturno.vigencia_final::timestamp without time zone,
                                                                          horario.data_hora_inicio) AND
                                                                  (escala.extraordinaria IS TRUE AND
                                                                   adicional_noturno.categoria::text =
                                                                   'EXTRA_ORD'::text OR
                                                                   escala.extraordinaria IS FALSE AND
                                                                   adicional_noturno.categoria::text =
                                                                   'ORDINARIA'::text)
WHERE grupo_escala.deleted_at IS NULL
  AND horario.deleted_at IS NULL
GROUP BY grupo_escala.id, grupo_escala.grupo, escala.id;

alter table carga_horaria_view
    owner to usr_bd_cbm_hub;

