create view gap_militar_view(militar_id, id, gap_id, inicio, created_at) as
SELECT DISTINCT ON (militar_id) militar_id,
                                id,
                                gap_id,
                                inicio,
                                created_at
FROM hub_bombeiro.gap_militar
WHERE deleted_at IS NULL
ORDER BY militar_id, inicio DESC;

alter table gap_militar_view
    owner to usr_bd_cbm_hub;

